import mysql.connector

mydb = mysql.connector.connect(
  host="127.0.0.1",
  user="root",
  database="adwatch"
  #passwd=""
)

mycursor = mydb.cursor()

#  FUNCIONES -------------------------------------------------------------------

def getAdName(hora,minuto):
	h= str(hora)
	m = str(minuto)
	hm =f"{h}:{m}:00"

	try:
		busqueda1 = f"SELECT AdWatch_fechatrans.anuncio_id FROM AdWatch_horariotrans JOIN AdWatch_fechatrans ON AdWatch_horariotrans.fecha_id=AdWatch_fechatrans.id WHERE AdWatch_horariotrans.tiempo = '{hm}' "
		mycursor.execute(busqueda1)
		myresult = mycursor.fetchall()
		resultado =[]
		for x in myresult:
			resultado.append(x[0])
		datos =[]
		for xi in resultado:
			consultar = f"SELECT auth_user.id, auth_user.username, AdWatch_anuncio.id, AdWatch_anuncio.titulo, AdWatch_anuncio.audioAnuncio FROM AdWatch_anuncio join auth_user WHERE AdWatch_anuncio.id={xi} AND AdWatch_anuncio.cliente_id=auth_user.id"
			mycursor.execute(consultar)
			myresult = mycursor.fetchall()
			datos.append(myresult)
		return datos
	except:
		print("Busqueda bloqueada")
		   
	

	
	
	

	
	
		

	

	
		
		
		

	


#datos = getAdName(17,20)
#try:
#	for i in datos[0]:
#		print(f"id:{i[0]} Nombre:{i[1]}  Anuncio: {i[3]} ")
#except:
#	print("no se encontro nada")

	


 