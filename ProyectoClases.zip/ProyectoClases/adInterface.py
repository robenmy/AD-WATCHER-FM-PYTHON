#!/usr/bin/env python3
from tkinter import*
import time
import threading
import main



'''
raiz = Tk()
raiz.title("ADWATCHER FM")
raiz.resizable(False, False)
#para agregar un logo a la ventana:
raiz.iconbitmap("image.ico")
raiz.geometry("900x550")
#Para cambiar color de ventana
raiz.config(bg="blue")
miframe = Frame() # se utiliza para colocar los botones o widget
miframe.pack()
miframe.config(bg="red")
miframe.config(width="900", height="550")
# para colocar imagen en la ventana
# miImagen = PhotoImage(file="mouse.gif")
# label(miframe, image=miImagen).place(x=100,y=200)
miFrame2=Frame(raiz)

miFrame2.pack(side=LEFT)
botonLeer=Button(miFrame2, text="DETENER", command=quit)
botonLeer.grid(row=0, column=0, sticky="n", padx=0,pady=0)

raiz.mainloop()
'''
# segunda parte ----------------------------
'''
# Configuración de la raíz
root = Tk()
root.title("Hola mundo")
root.resizable(1,1)
#root.iconbitmap('hola.ico')

frame = Frame(root, width=480, height=320)
frame.pack(fill='both', expand=1)
#frame.config(cursor="pirate")
frame.config(bg="lightblue")
frame.config(bd=25)
frame.config(relief="sunken")

#root.config(cursor="arrow")
root.config(bg="blue")
root.config(bd=15)
root.config(relief="ridge")

# Para centrar la ventana en medio de la pantalla
w = root.winfo_reqwidth()
h = root.winfo_reqheight()
ws = root.winfo_screenwidth()
hs = root.winfo_screenheight()
x = (ws/2) - (w/2)
y = (hs/2) - (h/2)
root.geometry('+%d+%d' % (x, y))

# Finalmente bucle de la aplicación
root.mainloop()
'''

# Tercera parte de prueba interfaz
import tkinter as tk
from tkinter import ttk

class Application(ttk.Frame):
    
    def __init__(self, main_window):
        super().__init__(main_window)
        main_window.title("ADWATCHER FM")
        self.x=True
        self.control_hilo =False

        
          #hilo
        main_window.configure(width=1000, height=400)

        self.place(relwidth=1, relheight=1)
        self.button = ttk.Button(self, text="START", command =self.botonStart)
        self.button1 = ttk.Button(self, text="STOP", command =self.botonStop)
        self.button.place(x=60, y=40, width=200, height=300)
        self.button1.place(x=300, y=40, width=200, height=300)
        #self.L1 = Label( text="Hora")
        #self.L1.place(x=500, y=50)  
        self.var = tk.StringVar()
        self.varaudio = tk.StringVar()
        self.var.set("ADWATCHER")
        self.varaudio.set("Muestra de Audio")


        self.entry = ttk.Entry( textvariable=self.var,state="readonly")#
        self.entry2 = ttk.Entry( textvariable=self.varaudio,state="readonly")
        self.entry.place(x=520, y=80)
        self.entry2.place(x=520, y=225)
        #self.entry.insert(END,self.valor)
        self.imagen = PhotoImage(file="Iconos/circul3.png")
        self.label = ttk.Label( image=self.imagen)
        self.label.place(x=520, y=120)
        #centrarVentana(self,main_window)

    def centrarVentana(self,root):
    	self.w = root.winfo_reqwidth()
    	self.h = root.winfo_reqheight()
    	self.ws = root.winfo_screenwidth()
    	self.hs = root.winfo_screenheight()
    	self.y = (self.hs/2) - (self.h/2)
    	self.x = (self.ws/2) - (self.w/2)
    	root.geometry('+%d+%d' % (self.x, self.y))

    def hola(self):
    	i=1
    	while self.x:
    		
    		main.mainAp(i)
    		#time.sleep(1)
    		#self.entry.delete(0,END)
    		#self.entry.insert(END,self.valor)
    		#self.var.set("nuevo")
    		

    		i+=1
    		
    	print("Proceso Terminado")

    def setColor(self):
    	if self.x :
    		self.imagen = PhotoImage(file="Iconos/circul2.png")
    		self.label = ttk.Label( image=self.imagen)
    		self.label.place(x=620, y=120)
    	else:
    		self.imagen = PhotoImage(file="Iconos/circul3.png")
    		self.label = ttk.Label( image=self.imagen)
    		self.label.place(x=520, y=120)




    def botonStart(self):
    	if self.control_hilo == False:
    		self.control_hilo =True
    		self.hilo = threading.Thread(name="start",target=self.hola, daemon=True)
    		self.setColor()
    		self.hilo.start()
            
    		

    	
    	
    	
    def botonStop(self):
    	if self.control_hilo == True:
    		main.stopSDR()
    		self.control_hilo =False
    		self.x=False
    		self.hilo.join()
    		self.setColor()
    		self.x= True
    		#self.var.set("-----     DETENIDO")
    	

if __name__ == "__main__":
	main_window = tk.Tk(className='Nautilus')
	app = Application(main_window)
	app.centrarVentana(main_window)
	app.mainloop()


# para colocar imagen en la ventana
# miImagen = PhotoImage(file="mouse.gif")
# label(miframe, image=miImagen).place(x=100,y=200)





