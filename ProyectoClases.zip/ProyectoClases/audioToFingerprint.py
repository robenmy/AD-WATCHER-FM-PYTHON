import pickle
import scipy.io.wavfile as waves
from scipy import signal
import scipy
import fingerprint as fp 
import os
import time
import bd_adwatch
import genTXT

def dbsearch(hora, minutos,ap,lista):
	h = int(hora)
	m = int(minutos)

	if m<55 and m>5:
		m=m-5

	if m>= 55:
		me = 59-m
		m = m-me

	for i in range(10):

		if m == 59 and h==24:
			h=1
			m=0
		if m == 59 and h>0 and h<=23:
			m =0
			h+=1
		m+=1
		ho = str(h)
		mi = str(m)

		busqueda_anuncio= bd_adwatch.getAdName(3,10)
		
		try:
			for i in busqueda_anuncio[0]:
				print(f"id:{i[0]} Nombre:{i[1]}  Anuncio: {i[3]} ")
				data=readdata(i[3])
				datos =[i[0],i[1],i[3],hora,minutos]
				comparacion(lista,data,datos,ap)
		except:
			print("no hay nada")
			#break
		#finally:
		#	comparacion(lista,data)

		
			
				#print(readdata(i[1]))
			
		

		#a,b =userdb.busquedaFing(ho,mi,ap)
		#if a[0] !=0:
		#	print(a)
		#	print(b)
		#	comparacion(lista,b)   # comparar lista de datos 
		
		


def comparacion(lista1,lista2, datos,ap):
	info = f"id:{datos[0]} Nombre:{datos[1]}  Anuncio: {datos[2]} Hora {datos[3]}:{datos[4]} "
	#print(lista2)
	contador = 0
	for i in lista1:
		for j in  lista2:
			if i==j:
				contador+=1

	if contador>3:
		print("++++++++++++++")
		print(f"----Existe Similitud---- Datos iguales: {contador}")
		print("++++++++++++++")
		genTXT.writeText("meta_data",info+" " +ap)
	else:
		print("NO EXISTEN SIMILITUDES")
		genTXT.writeText("meta_data",info+" >>No hay similitudes"+"  Direccion"+ap)
	




			

#########################################################333
def fingerprint(index, hora, minutos):
	filename = ">audio.wav"
	direccion="Audio/"+str(index)+filename
	#direccion2 = "Ads/tauroturbo.wav"
	while True:
		time.sleep(1)
		if os.path.isfile(direccion):
			muestreo, sonido = waves.read(direccion)
			#print(direccion)
			#mostrar_datos.set(direccion)
			#monoa = sonido[:,0]
			a =fp.fingerprint(sonido)
			#print("Fingerprint generado ..... Numero de Proceso: "+str(os.getpid()))
			lista=[]
			for aw in a:
				lista.append(aw[0])

			#lista2 =None
			#mostrar_datos.set("Fingerprint generado")

			#comparacion(lista,lista2)
			dbsearch(hora,minutos,direccion,lista)
			#dbsearch(3,10,'pm',lista)
			break

  	
	

#dbsearch('5','40','pm',['4','6','8','3'])
def readdata(filename):
	file=f"audioFingerprint/{filename}.data"
	lista=[]
	with open(file,'rb') as filehandle:
		lista = pickle.load(filehandle)

	return(lista)


