import os
import fingerprint as fp 
import pickle
import scipy.io.wavfile as waves
from scipy import signal
import scipy
import numpy as np


def checkFile():
	array = []
	print("OK")
	fileA = os.listdir("Ads")
	fileB = os.listdir("audioFingerprint")
	#fileB = os.listdir("/Home/Downloads")
	fileAudio =[]
	fileFP =[]

	for i in fileA:
		fileA, x = i.split('.wav')
		fileAudio.append(fileA)

	for j in fileB:
		#print(j)
		fileB, x = j.split('.data')
		fileFP.append(fileB)


	for st in fileAudio:
		if st in fileFP:
			print("ok")
			
		else:
			print(f"{st} no existe")
			array.append(st)

	if array != []:
		for audio in array:
			muestreo, sonido = waves.read(f"Ads/{audio}.wav")
			tamano = np.shape(sonido)

			if len(tamano) > 1: 
				sonido = sonido[:,0]
			#estereo con dos canales


			a =fp.fingerprint(sonido)
			lista=[]
			for aw in a:
				lista.append(aw[0])
			#print(lista)
			#audio, x = audio.split('.wav')
			file=f'audioFingerprint/{audio}.data'
			with open(file,'wb') as filehandle:
				pickle.dump(lista,filehandle)







	



