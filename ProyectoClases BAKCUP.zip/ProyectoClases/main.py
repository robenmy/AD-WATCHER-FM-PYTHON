
import demudalate_sample as dem
#import read_sample as sdr
import threading
import audioToFingerprint as af
#import client
import datetime
import soapy_sdr
import ads_to_fp as check


def mainAp(indice):
	tc = threading.Thread(target=check.checkFile,)# verifica que cada ads tega su fingerprint
	tc.start()

	if indice == 1:
		#import soapy_sdr
	    soapy_sdr.start(3e6,96.3e6)

	now = datetime.datetime.now()
	#valor.set(f"Capturando> {now.hour:02}:{now.minute:02}:{now.second:02}")
	soapy_sdr.capturarSamples()
	#if detener:

	t0 = threading.Thread(target=dem.frec_inte, args=(dem.load(), indice,))
	t1 = threading.Thread(target=af.fingerprint, args=(indice,now.hour,now.minute,))
	t0.start()
	t1.start()
	#soapy_sdr.capturarSamples()
	#soapy_sdr.capturarSamples()
	#print(f"Hora: {now.hour}:{now.minute}")
	#valor = f"{now.hour}:{now.minute}"
	#valor.set(f"Capturando> {now.hour}:{now.minute}:{now.second}")
	#t0 = threading.Thread(target=dem.frec_inte, args=(dem.load(), indice,))
	#t1 = threading.Thread(target=af.fingerprint, args=(indice,now.hour,now.minute,))
	#t0.start()
	#t1.start()
	

def stopSDR():
	soapy_sdr.stop()


#indice =1
#if __name__ == '__main__':
#	while True:
#		mainAp(indice)
		#sdr.guardar()
		#now = datetime.datetime.now()
		#client.client()
		#soapy_sdr.capturarSamples()
		#print(f"Hora: {now.hour}:{now.minute}")
		#t0 = threading.Thread(target=dem.frec_inte, args=(dem.load(), indice,))
		#t1 = threading.Thread(target=af.fingerprint, args=(indice,now.hour,now.minute,))
		#t0.start()
		#t1.start()
#		indice +=1
#		if indice == 3:
#			stopSDR()
#			break