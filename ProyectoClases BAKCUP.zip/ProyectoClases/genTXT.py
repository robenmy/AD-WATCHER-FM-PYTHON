def writeText(filename, message):
    #f= open("guru99.txt","w+")
    f=open(filename,"a+")
    #for i in range(10):
    f.write(message+"\n")
    f.close()

def readText(filename):
    f=open(filename,"r")
    fl= f.readlines()
    f.close() 
    return fl


#if __name__== "__main__":
#  writeText("guru99.txt","klk")
#  x = readText("guru99.txt")
#  for i in x:
#    print(i)
  