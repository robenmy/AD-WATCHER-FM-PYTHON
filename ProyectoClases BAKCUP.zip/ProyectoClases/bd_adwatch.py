import mysql.connector

mydb = mysql.connector.connect(
  host="127.0.0.1",
  user="root",
  database="adwatch"
  #passwd=""
)

mycursor = mydb.cursor()

#  FUNCIONES -------------------------------------------------------------------

def getAdName(hora,minuto):
	h= str(hora)
	m = str(minuto)
	hm =f"{h}:{m}:00"

	h2 = int(hora) + 1
	hm2 =f"{h2}:{m}:00"

	try:
		busqueda1 = f"SELECT AdWatch_fechatrans.anuncio_id FROM AdWatch_horariotrans JOIN AdWatch_fechatrans ON AdWatch_horariotrans.fecha_id=AdWatch_fechatrans.id WHERE AdWatch_horariotrans.tiempo >= '{hm}' AND  AdWatch_horariotrans.tiempo <= '{hm2}' "
		mycursor.execute(busqueda1)
		myresult = mycursor.fetchall()
		resultado =[]
		for x in myresult:
			resultado.append(x[0])
		datos =[]
		for xi in resultado:
			consultar = f"SELECT auth_user.id, auth_user.username, AdWatch_anuncio.id, AdWatch_anuncio.titulo, AdWatch_anuncio.audioAnuncio FROM AdWatch_anuncio join auth_user WHERE AdWatch_anuncio.id={xi} AND AdWatch_anuncio.cliente_id=auth_user.id"
			mycursor.execute(consultar)
			myresult = mycursor.fetchall()
			datos.append(myresult)
		return datos
	except:
		print("Busqueda bloqueada")
		   
	

	
	
	

def insertDatos(fecha, hora, id_anuncio):

	fechaHora = f"{fecha} {hora}"
	print(fechaHora)
		

	insertar = f" INSERT INTO AdWatch_registro(id, tiempo,fecha, anuncio_id, fingerprint_id, actualizado, creado) values(NULL,18,'{fecha}',{id_anuncio},1,'{fechaHora}','{fechaHora}');"
	
	mycursor.execute(insertar)
	mydb.commit()
	print("ok")




#insertDatos('2019-08-14','10:25:00', 2)
	
		

	

	
		
		
#print(getAdName(3,00))	

	



	


 